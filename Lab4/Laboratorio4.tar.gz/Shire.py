class Shire:

    def __init__(self, id, posX, posY, population, cancer_risk):
        self.id = id
        self.posX = posX
        self.posY = posY
        self.population = population
        self.cancer_risk = cancer_risk





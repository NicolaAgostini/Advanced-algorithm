class Edge:
    def __init__(self, departure_node, arrival_node, weight):
        self.departure_node = departure_node
        self.arrival_node = arrival_node
        self.weight = weight
